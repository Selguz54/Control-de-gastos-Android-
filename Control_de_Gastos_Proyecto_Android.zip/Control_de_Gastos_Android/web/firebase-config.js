// PASO NECESARIO: reemplaza estos valores con la configuración de tu proyecto Firebase.
// No pongas contraseñas privadas ni claves de servidor aquí. Esta configuración web
// identifica el proyecto; protege los datos con Authentication y las reglas de Firestore.
export const firebaseConfig = {
  apiKey: "REEMPLAZAR_API_KEY",
  authDomain: "REEMPLAZAR_PROJECT_ID.firebaseapp.com",
  projectId: "REEMPLAZAR_PROJECT_ID",
  storageBucket: "REEMPLAZAR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "REEMPLAZAR_MESSAGING_SENDER_ID",
  appId: "REEMPLAZAR_APP_ID"
};

export const firebaseIsConfigured = Object.values(firebaseConfig).every(
  value => typeof value === "string" &&
    value.length > 0 &&
    !value.startsWith("REEMPLAZAR")
);
