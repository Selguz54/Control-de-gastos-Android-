# Cómo generar tu APK solo con Android (sin PC)

La forma propuesta es usar GitHub Actions como computadora en la nube. El APK de prueba se compila en los servidores de GitHub y luego lo descargas desde tu teléfono.

## Lo que necesitas
- Una cuenta de GitHub.
- El archivo `Control_de_Gastos_Proyecto_Android.zip`.
- El archivo `build-apk.yml` de este paquete.

## Pasos desde el teléfono
1. Abre https://github.com en Chrome e inicia sesión o crea una cuenta.
2. Crea un repositorio nuevo llamado `control-de-gastos-android`.
3. Para el primer intento, elige **Public** para simplificar la ejecución de Actions. El ZIP inicial no incluye contraseñas ni claves privadas; Firebase aún tiene marcadores de posición. No subas archivos de firma, claves privadas ni contraseñas.
4. En el repositorio, toca **Add file > Upload files** y sube `Control_de_Gastos_Proyecto_Android.zip` a la raíz. Confirma con **Commit changes**.
5. Crea el workflow: **Add file > Create new file**. En el nombre escribe exactamente `.github/workflows/build-apk.yml`. Pega el contenido de `build-apk.yml` y toca **Commit changes**.
6. Abre la pestaña **Actions**. Si no empieza automáticamente, abre **Build Android APK**, pulsa **Run workflow** y confirma.
7. Cuando termine, abre la ejecución y baja a **Artifacts**. Descarga `Control-de-Gastos-APK-prueba`.
8. Extrae el ZIP descargado y abre `app-debug.apk`. Android puede pedirte permitir instalaciones desde esa fuente. Permite solo la fuente que utilizaste y desactívalo después si lo prefieres.

## Límites importantes
- Es un APK **de prueba/debug**, no una versión lista para publicar en Google Play.
- Los anuncios usan el identificador de prueba de Google y no generan ingresos.
- Firebase no funcionará hasta configurar el proyecto; la aplicación seguirá usando el almacenamiento local.
- Antes de usar tus datos reales, prueba con datos ficticios y conserva el HTML original.
- Si GitHub muestra un error rojo, abre la ejecución, copia aquí el paso fallido y el mensaje de error para corregirlo.

## Enlaces oficiales
- GitHub: https://github.com
- GitHub Actions: https://docs.github.com/actions
- Capacitor Android: https://capacitorjs.com/docs/android
