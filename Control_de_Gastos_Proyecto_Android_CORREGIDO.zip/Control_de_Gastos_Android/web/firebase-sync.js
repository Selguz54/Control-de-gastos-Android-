import { initializeApp } from "firebase/app";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, sendPasswordResetEmail
} from "firebase/auth";
import {
  getFirestore, doc, getDoc, setDoc, onSnapshot
} from "firebase/firestore";
import { firebaseConfig, firebaseIsConfigured } from "./firebase-config.js";

const KEYS = ["sobresFijos", "operativos", "diasSemanaLibre", "gastoExtraVal", "gastosDiaV1"];
const CLIENT_ID = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const $ = id => document.getElementById(id);
let auth, db, currentUser = null, cloudRef = null, stopListening = null;
let syncReady = false, suppressSync = false, pendingLocal = false, debounceTimer = null;
let lastSeenUpdatedAt = 0;

function status(message) {
  const el = $("cloudStatus");
  if (el) el.textContent = message;
}
function localSnapshot() {
  const state = {};
  for (const key of KEYS) {
    const value = localStorage.getItem(key);
    if (value !== null) state[key] = value;
  }
  return state;
}
function applySnapshot(state) {
  suppressSync = true;
  try {
    for (const key of KEYS) {
      if (Object.prototype.hasOwnProperty.call(state || {}, key)) {
        localStorage.setItem(key, String(state[key]));
      } else {
        localStorage.removeItem(key);
      }
    }
  } finally {
    suppressSync = false;
  }
  // The original HTML keeps some values in memory; rerun its initializer after restoring.
  if (typeof window.onload === "function") window.onload();
}
function patchStorage() {
  const originalSet = Storage.prototype.setItem;
  const originalRemove = Storage.prototype.removeItem;
  Storage.prototype.setItem = function(key, value) {
    originalSet.call(this, key, value);
    if (this === localStorage && KEYS.includes(String(key)) && syncReady && !suppressSync) queueUpload();
  };
  Storage.prototype.removeItem = function(key) {
    originalRemove.call(this, key);
    if (this === localStorage && KEYS.includes(String(key)) && syncReady && !suppressSync) queueUpload();
  };
}
function queueUpload() {
  pendingLocal = true;
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => uploadSnapshot(false), 900);
}
async function uploadSnapshot(manual = true) {
  if (!currentUser || !cloudRef) return;
  try {
    const now = Date.now();
    await setDoc(cloudRef, {
      state: localSnapshot(),
      updatedAt: now,
      updatedBy: CLIENT_ID
    });
    lastSeenUpdatedAt = now;
    pendingLocal = false;
    if (manual) status("Copia guardada en la nube. Cuenta: " + currentUser.email);
    else status("Sincronizado · " + currentUser.email);
  } catch (error) {
    status("No se pudo guardar en la nube: " + (error?.message || "error desconocido") + ". Tus datos locales siguen guardados.");
  }
}
function startLiveSync() {
  syncReady = true;
  if (stopListening) stopListening();
  stopListening = onSnapshot(cloudRef, snapshot => {
    if (!snapshot.exists()) return;
    const data = snapshot.data();
    const stamp = Number(data.updatedAt) || 0;
    if (data.updatedBy === CLIENT_ID || stamp <= lastSeenUpdatedAt) return;
    // A local edit already queued is kept; it will upload shortly. Avoid silently
    // overwriting unsent local changes with a remote snapshot.
    if (pendingLocal) {
      status("Hay cambios locales pendientes. Guardándolos antes de aplicar otra copia…");
      return;
    }
    applySnapshot(data.state || {});
    lastSeenUpdatedAt = stamp;
    status("Copia actualizada desde la nube · " + new Date(stamp).toLocaleString());
  }, error => status("Error de sincronización: " + (error?.message || "desconocido")));
}
async function prepareAccount(user) {
  currentUser = user;
  cloudRef = doc(db, "users", user.uid, "backups", "controlDeGastos");
  $("cloudAuthBox").classList.add("cloud-hidden");
  $("cloudSignedIn").classList.remove("cloud-hidden");
  $("cloudAccountLabel").textContent = "Sesión iniciada como " + user.email;
  syncReady = false;
  pendingLocal = false;
  if (stopListening) { stopListening(); stopListening = null; }
  try {
    const snap = await getDoc(cloudRef);
    if (snap.exists()) {
      lastSeenUpdatedAt = Number(snap.data().updatedAt) || 0;
      status("Hay una copia en la nube. Elige cuál conservar antes de activar la sincronización automática.");
      $("cloudRestore").disabled = false;
      $("cloudUpload").disabled = false;
    } else {
      lastSeenUpdatedAt = 0;
      status("Esta cuenta aún no tiene copia. Pulsa “Guardar este dispositivo en la nube” para crearla.");
      $("cloudRestore").disabled = true;
      $("cloudUpload").disabled = false;
    }
  } catch (error) {
    status("No se pudo consultar la copia: " + (error?.message || "revisa las reglas de Firestore"));
  }
}
async function doRestore() {
  if (!cloudRef) return;
  if (!confirm("Se reemplazarán en este dispositivo los datos de Control de Gastos con la copia de la nube. ¿Continuar?")) return;
  try {
    const snap = await getDoc(cloudRef);
    if (!snap.exists()) { status("Todavía no existe una copia en la nube."); return; }
    const data = snap.data();
    applySnapshot(data.state || {});
    lastSeenUpdatedAt = Number(data.updatedAt) || Date.now();
    startLiveSync();
    status("Copia restaurada y sincronización activada.");
  } catch (error) {
    status("No se pudo restaurar: " + (error?.message || "error desconocido"));
  }
}
async function doUpload() {
  if (!cloudRef) return;
  const snap = await getDoc(cloudRef).catch(() => null);
  if (snap?.exists()) {
    const ok = confirm("Esto reemplazará la copia actual de la nube con los datos de este dispositivo. Hazlo solo si esta es la copia que quieres conservar. ¿Continuar?");
    if (!ok) return;
  }
  await uploadSnapshot(true);
  startLiveSync();
}
function showLoggedOut() {
  currentUser = null;
  cloudRef = null;
  syncReady = false;
  pendingLocal = false;
  if (stopListening) { stopListening(); stopListening = null; }
  $("cloudAuthBox")?.classList.remove("cloud-hidden");
  $("cloudSignedIn")?.classList.add("cloud-hidden");
  status("Sesión cerrada. Tus datos locales siguen en este dispositivo.");
}
function bindButtons() {
  $("cloudLogin").addEventListener("click", async () => {
    try {
      await signInWithEmailAndPassword(auth, $("cloudEmail").value.trim(), $("cloudPassword").value);
    } catch (e) { status("No se pudo iniciar sesión: " + (e?.message || "revisa correo y contraseña")); }
  });
  $("cloudRegister").addEventListener("click", async () => {
    try {
      await createUserWithEmailAndPassword(auth, $("cloudEmail").value.trim(), $("cloudPassword").value);
    } catch (e) { status("No se pudo crear la cuenta: " + (e?.message || "revisa los datos")); }
  });
  $("cloudUpload").addEventListener("click", doUpload);
  $("cloudRestore").addEventListener("click", doRestore);
  $("cloudSignOut").addEventListener("click", async () => {
    try { await signOut(auth); } catch (e) { status("No se pudo cerrar sesión: " + e.message); }
  });
  // Long press / keyboard users can reset their password through the browser prompt.
  $("cloudPassword").addEventListener("keydown", async event => {
    if (event.key === "Enter") $("cloudLogin").click();
  });
  $("cloudEmail").addEventListener("change", () => {
    $("cloudEmail").setAttribute("aria-label", "Correo electrónico");
  });
}
patchStorage();

if (!firebaseIsConfigured) {
  status("La app funciona en modo local. Para activar el respaldo, configura web/firebase-config.js y habilita Email/Password y Firestore en Firebase.");
  $("cloudLogin").disabled = true;
  $("cloudRegister").disabled = true;
  $("cloudUpload").disabled = true;
  $("cloudRestore").disabled = true;
} else {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  bindButtons();
  onAuthStateChanged(auth, async user => {
    if (user) {
      try { await prepareAccount(user); }
      catch (error) { status("Error al preparar la cuenta: " + (error?.message || "desconocido")); }
    } else {
      showLoggedOut();
    }
  });
}
