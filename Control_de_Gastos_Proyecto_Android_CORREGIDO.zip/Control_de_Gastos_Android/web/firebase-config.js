export const firebaseConfig = {
  apiKey: "AIzaSyBThlP6t91ISu2k9i2qkJkzOtjhUUtwPHo",
  authDomain: "control-de-gastos-f66b8.firebaseapp.com",
  projectId: "control-de-gastos-f66b8",
  storageBucket: "control-de-gastos-f66b8.firebasestorage.app",
  messagingSenderId: "56374736042",
  appId: "1:56374736042:web:eb2b8d20295cf59b61ccd3",
};

export const firebaseIsConfigured = Object.values(firebaseConfig).every(
  (value) =>
    typeof value === "string" &&
    value.length > 0 &&
    !value.startsWith("REEMPLAZAR")
);
