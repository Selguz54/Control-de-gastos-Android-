import { Capacitor } from "@capacitor/core";
import { AdMob, BannerAdSize, BannerAdPosition } from "@capacitor-community/admob";

async function setupMobileAds() {
  if (!Capacitor.isNativePlatform()) return;
  document.body.classList.add("native-app");
  // Until a real AdMob banner ID is configured, Google's official Android test ID is used.
  const configuredId = import.meta.env.VITE_ADMOB_BANNER_ID || "";
  const isTesting = !configuredId;
  const bannerId = configuredId || "ca-app-pub-3940256099942544/6300978111";
  try {
    await AdMob.initialize({ initializeForTesting: isTesting });
    await AdMob.showBanner({
      adId: bannerId,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0
    });
  } catch (error) {
    console.warn("No se pudo mostrar el banner AdMob:", error);
  }
}
setupMobileAds();
