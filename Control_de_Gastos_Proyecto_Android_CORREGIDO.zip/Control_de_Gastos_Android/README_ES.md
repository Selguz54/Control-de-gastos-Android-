# Control de Gastos — base para APK Android

Esta carpeta reutiliza la versión HTML existente y la prepara para:
- empaquetado Android con Capacitor;
- cuentas por correo/contraseña y copia/sincronización en Firebase Firestore;
- anuncios nativos con AdMob en Android;
- conservar el recuadro de AdSense para la versión web.

## Qué incluye y qué falta

**Incluido:** HTML actual, panel de cuenta, módulo de respaldo, reglas de Firestore de ejemplo y el puente de anuncios Android. La sincronización se activa cuando configures Firebase.

**Aún no es un APK compilado.** Para compilarlo necesitas una computadora con Node.js y Android Studio/Android SDK. Este ZIP es el proyecto fuente que genera el APK.

## 1. Requisitos

- Node.js compatible con Vite 7 (Node 20.19+ o 22.12+ recomendado).
- Android Studio con Android SDK instalado.
- Una cuenta de Google para configurar Firebase y AdMob.

## 2. Instalar dependencias y crear el proyecto Android

Desde una terminal, dentro de esta carpeta:

```bash
npm install
npm run build
npm run android:add
npx cap sync android
npx cap open android
```

En Android Studio, espera a que Gradle termine de sincronizar. Usa Run para probar en un dispositivo Android o crea un APK desde Build > Build Bundle(s) / APK(s) > Build APK(s).

Si ya existe una carpeta `android/`, no ejecutes `npm run android:add` otra vez; utiliza `npm run android:sync`.

## 3. Activar respaldo y sincronización con Firebase

1. En Firebase Console crea un proyecto.
2. Agrega una aplicación web y copia su configuración en `web/firebase-config.js`, reemplazando todos los textos `REEMPLAZAR_...`.
3. En Authentication > Sign-in method, habilita **Email/Password**.
4. Crea una base de datos en Firestore.
5. Publica las reglas de `firestore.rules` en Firestore Rules.
6. Ejecuta `npm run build` y `npx cap sync android` de nuevo.

Al iniciar sesión en un dispositivo, elige explícitamente si quieres **guardar la copia local en la nube** o **restaurar la copia de la nube**. Esto evita sobrescribir datos en la primera conexión.

### Importante sobre la sincronización inicial

Esta primera versión sincroniza una copia completa de las claves existentes (`sobresFijos`, `operativos`, `diasSemanaLibre`, `gastoExtraVal`, `gastosDiaV1`). Está diseñada como respaldo y sincronización sencilla, no como edición simultánea multiusuario. Si editas la misma cuenta en dos dispositivos al mismo tiempo, una copia reciente puede reemplazar cambios de la otra. Para publicar al público conviene evolucionar a sincronización por registro con historial de cambios y recuperación de versiones.

La configuración Firebase de cliente no es una contraseña secreta; la seguridad depende de Authentication y las reglas de Firestore. Nunca publiques reglas abiertas que permitan a cualquiera leer o escribir todos los datos.

## 4. Publicidad

### Android: AdMob
- El código usa el **ID de banner de prueba oficial** de Google mientras `VITE_ADMOB_BANNER_ID` esté vacío.
- Para producción, crea una aplicación Android y un bloque de banner en AdMob. Copia el ID del bloque en `.env.local` como `VITE_ADMOB_BANNER_ID=ca-app-pub-.../...`.
- Añade el **ID de aplicación AdMob** en `android/app/src/main/AndroidManifest.xml`, dentro de `<application>`:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY" />
```

Reemplaza el ejemplo por tu ID de aplicación real de AdMob (no el ID del bloque). Luego ejecuta `npm run android:sync`. No uses anuncios de prueba para generar ingresos y no hagas clic en tus propios anuncios.

### Web: AdSense
El HTML mantiene el recuadro visual de publicidad. Para mostrar anuncios reales en la web necesitas un sitio web publicado en HTTPS, una cuenta de AdSense aprobada, el script oficial de tu editor y el ID del bloque. No pegues el script de AdSense en la app Android; la app usa AdMob.

## 5. Prueba segura antes de publicar

1. Conserva una copia del HTML anterior.
2. Prueba la app con los anuncios de prueba.
3. Crea una cuenta de prueba y confirma que se guardan y restauran los datos.
4. Prueba agregar y eliminar un gasto y un reinicio por período.
5. No publiques el APK hasta probar la sincronización y configurar las políticas de privacidad y consentimiento publicitario aplicables.

## Referencias oficiales

- Capacitor: https://capacitorjs.com/docs/getting-started
- Capacitor Android: https://capacitorjs.com/docs/android
- Firebase Authentication: https://firebase.google.com/docs/auth
- Cloud Firestore: https://firebase.google.com/docs/firestore
- Capacitor Community AdMob: https://github.com/capacitor-community/admob
- Google AdMob: https://admob.google.com/
- Google AdSense: https://adsense.google.com/
