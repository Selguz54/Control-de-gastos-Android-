# Control de Gastos — proyecto Android local

Esta versión empaqueta el HTML aprobado dentro de una app Android con Capacitor.

## Privacidad y almacenamiento

- **No usa Firebase, cuentas, Firestore ni sincronización en la nube.**
- Los presupuestos, la moneda elegida, los ingresos diarios y los gastos se guardan en el almacenamiento local de la aplicación (WebView/localStorage).
- Los datos permanecen al cerrar y volver a abrir la app mientras siga instalada y no se borren sus datos desde los ajustes de Android.
- **Desinstalar la app o borrar sus datos puede eliminar los registros locales.** Exporta el informe `.txt` desde “Finalizar período” para conservar una copia fuera de la app.
- El informe `.txt` se genera localmente; no se envía a ningún servidor.
- No hay publicidad ni SDK de anuncios integrados.

## Requisitos para compilar

- Node.js 22 (o una versión compatible con Vite 7).
- Java 21 y Android SDK/Android Studio, si compilas localmente.

## Compilar

Dentro de esta carpeta:

```bash
npm install
npm run build
npx cap add android   # solo la primera vez
npx cap sync android
```

Si ya existe la carpeta `android/`, no ejecutes `npx cap add android` otra vez; ejecuta `npm run android:sync`. Después abre el proyecto con `npm run android:open` o compila un APK debug desde Android Studio.

## Construcción con GitHub Actions

El flujo `build-apk.yml` construye un APK debug y lo publica como artefacto descargable durante 7 días. El APK debug sirve para instalar y probar; antes de distribuirlo ampliamente conviene generar una versión firmada de lanzamiento.

## Pruebas antes de usarlo como definitivo

1. Instala el APK en el teléfono.
2. Introduce un presupuesto, cambia la moneda y registra ingresos y gastos.
3. Cierra la app desde recientes y vuelve a abrirla; confirma que los datos siguen ahí.
4. Genera el informe `.txt` y verifica que contiene los datos correctos.
5. Prueba los botones de borrado: cada uno debe pedir confirmación.
6. Antes de desinstalar o borrar datos de Android, exporta los informes que quieras conservar.


## Publicidad recompensada (preparación inicial)

Las dos acciones de informe ahora requieren completar un anuncio recompensado dentro del APK Android. Si el anuncio no termina o el SDK no confirma la recompensa, no se descarga el TXT y, especialmente, no se reinicia el período ni se borran los registros.

**Estado actual: SOLO IDs DE PRUEBA de Google AdMob.** No generan ingresos. Antes de publicar, el propietario debe crear una app Android en AdMob, reemplazar el App ID de prueba en `capacitor.config.json` y el ID de anuncio recompensado en `web/index.html`, quitar `initializeForTesting: true` / `isTesting: true`, y probar en un dispositivo real. La cuenta y los IDs reales son necesarios para monetizar. No se usa Firebase para guardar los gastos.

La publicidad requiere conexión a internet; los datos de gastos siguen guardándose localmente.
