# Guía breve desde Android

El proyecto está configurado para guardar los datos **solo en el teléfono**, sin cuentas ni nube.

Para obtener un APK con GitHub Actions, sube el archivo `Control_de_Gastos_Proyecto_Android.zip` a la raíz del repositorio que usa el flujo de compilación y ejecuta la acción `Build Android APK`. Descarga el artefacto `Control-de-Gastos-APK-local`.

Si vas a compilar desde una computadora, instala Node.js 22, Java 21 y Android Studio; luego sigue los comandos del `README_ES.md`.

**Importante:** el almacenamiento local vive dentro de la app. Si la desinstalas o borras sus datos desde Ajustes de Android, podrías perder el historial. Usa “Finalizar período” para exportar el informe `.txt`.


### Publicidad recompensada
El proyecto incluye la integración inicial de AdMob con IDs de prueba. No produce ingresos hasta que configures los IDs reales de tu cuenta. No borres el período si el anuncio no confirma la recompensa. Consulta README_ES.md antes de publicar.
